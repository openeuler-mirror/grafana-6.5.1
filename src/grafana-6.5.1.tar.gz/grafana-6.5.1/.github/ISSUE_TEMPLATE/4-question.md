---
name: Support request
about: 'Question or support request relating to using Grafana'
title: ''
labels: ''
assignees: ''
---

STOP -- PLEASE READ!

GitHub is not the right place for questions and support requests.

Please ask questions on our community site: [https://community.grafana.com/](https://community.grafana.com/)


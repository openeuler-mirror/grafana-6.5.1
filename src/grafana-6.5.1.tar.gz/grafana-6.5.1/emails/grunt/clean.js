module.exports = function(config) {
  return {
    dist: ['dist'],
  };
};

+++
title = "Project"
type = "docs"
identifier = "project"
weight = 6
+++

# Welcome to the grafana project

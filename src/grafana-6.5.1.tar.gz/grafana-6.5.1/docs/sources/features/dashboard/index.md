+++
title = "Dashboard Features"
type = "docs"
[menu.docs]
identifier = "dashboard_features"
parent = "features"
weight = 4
+++

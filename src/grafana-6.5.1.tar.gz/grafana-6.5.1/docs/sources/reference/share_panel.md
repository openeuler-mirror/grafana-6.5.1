+++
title = "Sharing a Panel"
keywords = ["grafana", "dashboard", "documentation", "sharing"]
type = "docs"
[menu.docs]
parent = "dashboard_features"
weight = 6
+++

# Share Panel

Click a panel title to open the panel menu, then click share in the panel menu to open the Share Panel dialog. Here you have access to a link that will take you to exactly this panel with the current time range and selected template variables. Below are ways to share a panel.

## Direct Link Rendered Image

You also get a link to render a PNG image of the panel. Useful if you want to share an image of the panel. Read more about the requirements and how to configure image rendering [here](/administration/image_rendering/).

Example of a link to a server-side rendered PNG:

```bash
https://play.grafana.org/d/000000012/grafana-play-home?orgId=1&from=1568719680173&to=1568726880174&panelId=4&fullscreen
```

#### Query String Parameters For Server-Side Rendered Images

- **width**: width in pixels. Default is 800.
- **height**: height in pixels. Default is 400.
- **tz**: timezone in the format `UTC%2BHH%3AMM` where HH and MM are offset in hours and minutes after UTC
- **timeout**: number of seconds. The timeout can be increased if the query for the panel needs more than the default 30 seconds.

## Embed Panel

You can embed a panel using an iframe on another web site. This tab will show you the html that you need to use.

> *Notice* This sharing require either anonymous access or setting [cookie_samesite]({{< relref "installation/configuration.md#cookie-samesite" >}}) to none

Example:

```html
<iframe src="https://snapshot.raintank.io/dashboard-solo/snapshot/y7zwi2bZ7FcoTlB93WN7yWO4aMiz3pZb?from=1493369923321&to=1493377123321&panelId=4" width="650" height="300" frameborder="0"></iframe>
```

Below there should be an interactive Grafana graph embedded in an iframe:

<iframe src="https://snapshot.raintank.io/dashboard-solo/snapshot/y7zwi2bZ7FcoTlB93WN7yWO4aMiz3pZb?from=1493369923321&to=1493377123321&panelId=4" width="650" height="300" frameborder="0"></iframe>

#### Export Panel Data

{{< docs-imagebox img="/img/docs/v50/export_panel_data.png" max-width="500px" >}}

The submenu for a panel can be found by clicking on the title of a panel and then on the More submenu.

This menu contains two options for exporting data:

- The panel JSON (the specification and not the data) can be exported or updated via the panel context menu.
- Panel data can be exported in the CSV format for Table and Graph Panels.
